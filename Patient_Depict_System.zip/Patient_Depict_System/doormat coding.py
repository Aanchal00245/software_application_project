#n,m=map(int,input().split())
#pattern=[('.|.'*(2*i+1)).center(m,'-') for i in range(n//2)]
#print('\n'.join(pattern+['WELCOME'.center(m,'-')]+pattern[: : -1]))

'''

def merge_the_tool (string, k):
          for i in range(0, len(string), k):
                     unique = ''
                     for c in string[i: i+k]:
                               if c not in unique:
                                         unique += c
                     print(unique)
merge_the_tool("aabccaadaaabaacada", 3)

def merge_the_tool (string, k):
          l=[]
          m=0
          for i in range(len(string)//K):
                     l.append(string[m:m+k])
                     m+=k
          print (l)
          for v in l:
                    print(list(v))
                    print(dict.fromkeys(list(v)))
                    print(dict.fromkeys(list(v), 1))
                    print(dict.fromkeys(list(v)).keys())
                    print(list(dict.fromkeys(list(v)).keys()))
                    print(''.join(list(dict.fromkeys(list(v)).keys())))

string = input("Enter the string: ")
K = int(input("Enter the value of K: "))
merge_the_tool(string, K)
'''
def count_substring(string, sub_string):
          count=0
          for i in range (0,len(string)):
                    if string [1: ].startswith(sub_string):
                              count+=1
          return count 
          

