from tkinter import *
from PIL import ImageTk,Image
import os
def next():
          #win.destroy()
           os.system('Login.py')
win =Tk()
win. title('software parels')

img=ImageTk.PhotoImage(file="Image\\Front5.jpg")
L1=Label(win,image=img)
L1.place(x=0,y=0)

x_res=win.winfo_screenwidth()
y_res=win.winfo_screenheight()
win.geometry("%dx%d"%(x_res,y_res))

l1=Label(win,text='HOSPITAL')
l1.config(bg='#0a1825',fg='white',font=('Algerina',20,'bold'))
l1.place(x=79,y=30)

img1=ImageTk.PhotoImage(file="Image\\Logo1.png")
L2=Label(win,image=img1)
L2.place(x=150,y=80)

L3=Label(win,text=' PATIENT DEPICT SYSTEM')
L3.config (bg="#0a1825",fg='white',font=('Arial unicode ms',40,'bold'))
L3.place(x=350,y=70)

L4=Label(win,text='PATIENT FIRST')
L4.config (bg="#0a1825",fg='white',font=('Algerina',20,'bold'))
L4.place(x=580,y=150)


b1=Button(win,text="Next",command=next)
b1.config(bg='#0a1825',fg='white',font=('consolas',20,'bold'))
b1.place(x=1150,y=550)
win.mainloop()


