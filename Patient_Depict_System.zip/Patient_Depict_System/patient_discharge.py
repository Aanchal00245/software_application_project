from tkinter import*
from PIL import ImageTk,Image
import mysql.connector
from tkcalendar import Calendar
from datetime import date
from datetime import datetime
from tkinter import messagebox
import mysql.connector as c
import smtplib
from email.mime.text import MIMEText
import random
import tkinter.filedialog as fd
import os 


def dashboard():
          os.system('dasboard.py')
          
def imageUploader():
    
    fileTypes = [('Image files','*.png;*.jpg;*.jpeg')]
    path = fd.askopenfilename(filetypes=fileTypes)
    onlyfilename = os.path.basename(path)
    #messagebox.showinfo("PATH",onlyfilename)
    # if file is selected
    if len(path):
        img = Image.open(path)
        img = img.resize((80, 80))
        pic = ImageTk.PhotoImage(img)
        img.save("F:\\Tkinter\\uplodertinker\\"+onlyfilename+".png")
        # re-sizing the app window in order to fit picture
        # and buttom
        label.config(image=pic)
        label.image = pic

    # if no file is selected, then we are displaying below message
    else:
        print('No file is chosen !! Please choose a file.')
        
def calculate():
          pass
          

def show():
          
          REGISTRATION_NUMBER=regno.get()
          htcon=mysql.connector.connect(host='localhost',username='root',password='root',database='hospital1')
          cur=htcon.cursor()
          query='select * from patadmit where  REGISTRATION_NO=%s'
          arg=(REGISTRATION_NUMBER,)
          cur.execute(query,arg)
          res=cur.fetchall()
          messagebox.showinfo("EXECUTE",'details found')
     
          patname.set(res[0][0])
          patdate.set(res[0][16])
          Phno.set(res[0][17])
          ward.set(res[0][4])
          splty.set(res[0][5])
          med.set(res[0][14])
          soemail()
          discharge=date.today()
          disdate=discharge.strftime('%d/%m/%y')
          dischargedate.set(str(disdate))


           # Call to calculate admit days
          calculate_admit_days()
          
          
         # sodoctorname()
          
          cur.close()
          htcon.close()
          
          
          
          

def calculate_admit_days():
          try:
                    admission_date_str = patdate.get()
                    discharge_date_str = dischargedate.get()

        
                    admission_date = datetime.strptime(admission_date_str, '%d/%m/%y')
                    discharge_date = datetime.strptime(discharge_date_str, '%d/%m/%y')

                     # Calculate the difference in days
                    days_admitted = (discharge_date - admission_date).days
                    messagebox.showinfo(' ',str(days_admitted))
                    #nodays=int(days_admitted)
                     # Set the number of admit days in the entry field
                    admitdays.set(str(days_admitted))

          except ValueError:
                    messagebox.showerror("Invalid Date", "Please ensure the admission and discharge dates are in 'DD/MM/YY' format.")
         

def calculate():
          try:
                    ward_charge = float(wardcharges.get()) if wardcharges.get() else 0
                    dr_charge = float(drcharges.get()) if drcharges.get() else 0
                    admit_days = int(admitdays.get()) if admitdays.get() else 1  # Default to 1 if not provided
                    service_charge = float(servicechrg.get()) if servicechrg.get() else 0
                    gst_charge = float(gst.get()) if gst.get() else 0

        
                    total_amount = (ward_charge + dr_charge + service_charge) * admit_days
                    total_amount += gst_charge  # Adding GST charge

        
                    total.set(f"{total_amount:.2f}")

          except ValueError:
                     messagebox.showerror("Invalid Input", "Please enter valid numeric values.")





          
def soemail():
          REGISTRATION_NUMBER=regno.get()
          htcon=mysql.connector.connect(host='localhost',username='root',password='root',database='hospital1')
          cur=htcon.cursor()
          query='select * from patreg where preg=%s'
          arg=(REGISTRATION_NUMBER,)
          cur.execute(query,arg)
          res=cur.fetchall()
          #messagebox.showinfo("EXECUTE",'details found')

          email.set(res[0][8])
          
          '''        
def sodoctorname():
          REGISTRATION_NUMBER=regno.get()
          htcon=mysql.connector.connect(host='localhost',username='root',password='root',database='hospital1')
          cur=htcon.cursor()
          query='select * from dctreg where aplcno=%s'
          arg=(REGISTRATION_NUMBER,)
          cur.execute(query,arg)
          res=cur.fetchall()
          #messagebox.showinfo("EXECUTE",'details found')

          fullname.set(res[0][0])

     '''     
          
def submit():
          pass
          




'''                     
def update() :
          REGISTRATION_NO=regno.get()
          Phone_No=Phno.get()
          EMAIL=email.get()
          Charges_as_per_Ward=wardcharges.get()
          Charges_as_per_doctor_speciality=drcharges.get()
          Number_of_days_admitted=admitdays.get()
          Charges_as_per_Services_taken=servicechrg.get()
          Gst_Charge=gst.get()
          
          con=c.connect(host='localhost',username='root',password='root',database='hospital1')
          cur=con.cursor()
          query ="update patadmit set PHONENO=%s,EMAIL=%s,WARDCHARGES=%s,DRCHRG=%s,ADMITDAYS=%s ,SERVICECHRG=%s,GST=%s where REGISTRATION_NO=%s"
          arg=(Phone_No,EMAIL,Charges_as_per_Ward, Charges_as_per_doctor_speciality,Number_of_days_admitted,Charges_as_per_Services_taken,Gst_Charge,REGISTRATION_NO)
          cur.execute(query, arg)#instance change in MYSQL
          con.commit() 
          cur.close()
          con.close()
          messagebox.showinfo('UPDATING','DATA UPDATED SUCCESSFULLY')
'''          

  
          


win=Tk()
win.config(bg='#4b92e1')
win.title('Software parel')

img=ImageTk.PhotoImage(file="Image\\discharge.jpg")
l=Label(win,image=img)
l.place(x=25,y=10)

x_res=win.winfo_screenwidth()
y_res=win.winfo_screenheight()
win.geometry("%dx%d"%(x_res,y_res))

Dataframe = Frame(win, bd=3, relief=GROOVE,bg='white')#bd=border width of 20,RIDGE
Dataframe.place( x=25,y=136,width=1315, height=554)

l1=Label(win,text="REGISTRATION NUMBER")
l1.config(bg='#7286D3',fg='white',font=('Arial',15,'bold'))
l1.place(x=35,y=163)
regno=StringVar()
t1=Entry(win,textvariable=regno);
t1.config(bg='white',fg='BLACK',width=20,border=0,font=('Arial',18,'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t1.place(x=290,y=163,height=31)

l2=Label(win,text=" PATIENT NAME ")
l2.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l2.place(x=35,y=205)
patname=StringVar()
t2=Entry(win,textvariable=patname);
t2.config(bg='white',fg='BLACK',width=33,border=0,font=('Arial',18,'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t2.place(x=35,y=240,height=35)

l3=Label(win,text=" FULLNAME ")
l3.config(bg='white',fg='navy',font=('Arial',9,'bold'))
l3.place(x=35,y=280)




l4=Label(win,text="ADMISSION DATE")
l4.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l4.place(x=500,y=203)
patdate= StringVar()
l5=Label(win,textvariable=patdate,width=19,font=('Arial',14,'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
l5.config(bg='white',fg='black',)
l5.place(x=530,y=244)

img1=ImageTk.PhotoImage(file="Image\\calendar.jpg")
l6=Label(win,image=img1)
l6.place(x=500,y=246)



l7=Label(win,text="EMAIL")
l7.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l7.place(x=35,y=300)
email=StringVar()
t8=Entry(win, textvariable=email)
t8.config(bg='white', fg='black', width=33, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t8.place(x=35, y=330, height=35)


l8=Label(win,text="Phone No")
l8.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l8.place(x=500,y=300)
Phno=StringVar()
t9=Entry(win, textvariable=Phno)
t9.config(bg='white', fg='black', width=33, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t9.place(x=500, y=330, height=35)

l10=Label(win,text="Ward Name")
l10.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l10.place(x=35,y=370)
ward=StringVar()
t10=Entry(win, textvariable=ward)
t10.config(bg='white', fg='black', width=15, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t10.place(x=35, y=400, height=35)

l11=Label(win,text="Charges as per Ward ")
l11.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l11.place(x=270,y=370)
wardcharges=StringVar()
t11=Entry(win, textvariable=wardcharges)
t11.config(bg='white', fg='black', width=15, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t11.place(x=270, y=400, height=35)

l12=Label(win,text="Speciality")
l12.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l12.place(x=35,y=440)
splty=StringVar()
t12=Entry(win, textvariable=splty)
t12.config(bg='white', fg='black', width=15, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t12.place(x=35, y=470, height=35)

l13=Label(win,text="Doctor Name")
l13.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l13.place(x=270,y=440)
dr=StringVar()
t13=Entry(win, textvariable=dr)
t13.config(bg='white', fg='black', width=15, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t13.place(x=270, y=470, height=35)

l14=Label(win,text="Charges as per doctor speciality")
l14.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l14.place(x=500,y=440)
drcharges=StringVar()
t14=Entry(win, textvariable=drcharges)
t14.config(bg='white', fg='navy', width=20, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t14.place(x=500, y=470, height=35)

l15=Label(win,text="Number of days admitted")
l15.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l15.place(x=950,y=300)
admitdays=StringVar()
t15=Entry(win, textvariable=admitdays)
t15.config(bg='white', fg='black', width=20, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t15.place(x=950, y=330, height=35)


l16=Label(win,text="DISCHARGE DATE")
l16.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l16.place(x=810,y=203)
admitdays=StringVar()
dischargedate= StringVar()
l16=Label(win,textvariable=dischargedate,width=20,font=('Arial',14,'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
l16.config(bg='white',fg='black')
l16.place(x=810,y=243)
img2=ImageTk.PhotoImage(file="Image\\calendar.jpg")
l21=Label(win,image=img2)
l21.place(x=780,y=243)


l17=Label(win,text="Charges as per Services taken")
l17.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l17.place(x=500,y=370)
servicechrg=StringVar()
t16=Entry(win, textvariable=servicechrg)
t16.config(bg='white', fg='black', width=20, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t16.place(x=500, y=400, height=35)


l18=Label(win,text="Mediclaim ")
l18.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l18.place(x=35,y=510)
med=StringVar()
t17=Entry(win, textvariable=med)
t17.config(bg='white', fg='black', width=20, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t17.place(x=35, y=550, height=35)

l19=Label(win,text="Gst Charge")
l19.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l19.place(x=310,y=510)
gst=StringVar()
t17=Entry(win, textvariable=gst)
t17.config(bg='white', fg='black', width=20, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t17.place(x=310, y=550, height=35)

l20=Label(win,text="Total")
l20.config(bg='white',fg='navy',font=('Arial',15,'bold'))
l20.place(x=35,y=590)
total=StringVar()
t18=Entry(win, textvariable=total)
t18.config(bg='white', fg='black', width=20, border=0, font=('Arial', 18, 'bold'),highlightthickness=2, highlightbackground='gray', highlightcolor='navy')
t18.place(x=35, y=620, height=35)


#Buttons
b1=Button(win,text="show",command=show)
b1.config(bg='red',fg='white',font=('Arial',11,'bold'))
b1.place(x=560,y=163)

b2=Button(win,text="submit",command=submit)
b2.config(bg='red',fg='white',font=('Arial',13,'bold'))
b2.place(x=400,y=620)

b3=Button(win,text="Calculate",command=calculate)
b3.config(bg='red',fg='white',font=('Arial',13,'bold'))
b3.place(x=310,y=620)
'''
b4=Button(win,text="UPDATE",command=update)
b4.config(bg='red',fg='white',font=('Arial',12,'bold'))
b4.place(x=470,y=620)
'''
b5=Button(win,text="Select Image",command=imageUploader)
b5.config(bg='red',fg='white',font=('tahoma',10),width=10)
b5.place(x=1200,y=230)
label=Label(win,text="")
label.config(bg='white')
label.place(x=1200,y=143)


win.mainloop()
