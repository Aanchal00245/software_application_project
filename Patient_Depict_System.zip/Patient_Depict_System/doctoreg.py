from tkinter import *
from PIL import ImageTk,Image
from tkinter import messagebox
import tkinter as tk
import os
from tkcalendar import Calendar
import mysql.connector as c


#CALENDAR
down=True
def down():
          global down
          if down:
                    var16.set(str(cal.get_date()))
                    cal.place(x=100, y=200, height=245, width=245)
                    down= False
          else:
                     var16.set(str(cal.get_date()))
                     cal.place(x=0, y=0, height=0, width=0)
                     down= True
         

def new():
          
          var1.set('')#to make the entry box empty
          var2.set('')
          var3.set('')
          var4.set('')
          var5.set('')
          var6.set('')
          var7.set('')
          var8.set('')
          var9.set('')
          var10.set('')
          var11.set('')
          var12.set('')
          var13.set('')
          var16.set('')
          var17.set('Department')
          var18.set('Gender')
          t1.config(state='normal')
          t3.config(state='normal')
          t6.config(state='normal')
          t7.config(state='normal')
          t8.config(state='normal')
          t9.config(state='normal')
          t10.config(state='normal')
          t11.config(state='normal')
          t13.config(state='normal')
          t14.config(state='normal')
          t15.config(state='normal')
          t16.config(state='normal')
          t17.config(state='normal')
          
          b1['state']=tk.DISABLED
          b2['state']=tk.NORMAL
          b3['state']=tk.NORMAL
          b4['state']=tk.DISABLED
          b5['state']=tk.NORMAL
          b6['state']=tk.DISABLED
          b7['state']=tk.NORMAL
          Mstatus.set(None)
         
          t1.focus_set()#to set the cursor on given entry box
          
def save():
          if not all([var1.get(), var16.get(), var2.get(), var3.get(), var4.get(), var5.get(), var6.get(), var7.get(), var8.get(), var9.get(), var10.get(), var11.get(), var12.get(), var13.get(), var17.get(), var18.get()]):
              messagebox.showerror("Error", "Please fill all the fields")
              return 
          
          b1['state'] = tk.NORMAL # makes the button visible
          b2['state'] = tk.DISABLED    # Hide the button
          b3['state'] = tk.DISABLED
          b4['state'] = tk.NORMAL
          b5['state'] = tk.DISABLED
          b6['state'] = tk.DISABLED
          b7['state'] = tk.DISABLED


          MAR=Mstatus.get()
          MSTATUS= ''
          if MAR==1:
                    MSTATUS='Married'
          elif MAR ==2:
                    MSTATUS='Single'
          elif MAR == 3:
                    MSTATUS='divorce'
          else:
                    MSTATUS=='widow'
          
                              
    
          fullname = var1.get()
          dob=var16.get()
          aplcno = var2.get()
          address = var3.get()
          city = var4.get()
          state = var5.get()
          zips = var6.get()
          country = var7.get()
          phoneno = var8.get()
          email = var9.get()
          passportno = var10.get()
          citizenship = var11.get()
          nospouse = var12.get()
          emgcontact = var13.get()
          specify=var17.get()
          gender=var18.get()
          MST()
          con = c.connect(host='localhost', username='root', password='root', database='hospital1')
          cur = con.cursor()
          query = "INSERT INTO dctreg VALUES (%s,%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s)"
          arg = (fullname, dob,aplcno, address, city, state, zips, country, phoneno, email, passportno, citizenship, nospouse, emgcontact,specify,gender,MSTATUS)
          cur.execute(query, arg)

          con.commit() 
          cur.close()
          con.close()
          messagebox.showinfo('VERIFYING ','DATA INSERTED SUCCESSFULLY')
          
 
          
          
def search():
          
          fullname =var1.get()
          con=c.connect(host='localhost',username='root',password='root',database='hospital1')
          cur=con.cursor()     
          query="select * from dctreg where fullname =  %s"
          arg=(fullname,)     #tuple
          cur.execute(query,arg)
          res = cur.fetchall()
          messagebox.showinfo('VERIFYING','SEARCHING COMPLETED ')
          var2.set(res[0][2])
          var3.set(res[0][3])
          var4.set(res[0][4])
          var5.set(res[0][5])
          var6.set(res[0][6])
          var7.set(res[0][7])
          var8.set(res[0][8])
          var9.set(res[0][9])
          var10.set(res[0][10])
          var11.set(res[0][11])
          var12.set(res[0][12])
          var13.set(res[0][13])
          var16.set(res[0][1])
          var17.set(res[0][14])
          var18.set(res[0][15])
          MAR=res[0][16]
          if MAR=='Married':
                    Mstatus.set(value=1)
          elif MAR =='Single':
                    Mstatus.set(value=2)
          elif MAR == 'divorce':
                    Mstatus.set(value=3)
          elif MAR == 'widow':
                    Mstatus.set(value=4)
          
          cur.close()
          con.close()
          b3['state']=tk.DISABLED
          b2['state']=tk.DISABLED
          b1['state']=tk.NORMAL
          b4['state']=tk.NORMAL
          b5['state']=tk.NORMAL
          b6['state']=tk.NORMAL
          b7['state']=tk.NORMAL
                             
def update():
          fullname = var1.get()
          aplcno = var2.get()
          address = var3.get()
          city = var4.get()
          state = var5.get()
          zips = var6.get()
          country = var7.get()
          phoneno = var8.get()
          email = var9.get()
          passportno = var10.get()
          citizenship = var11.get()
          nospouse = var12.get()
          emgcontact =var13.get()
          specify=var17.get()
          gender=var18.get()
          MAR=Mstatus.get()
          MSTATUS= ''
          if MAR==1:
                    MSTATUS='Married'
          elif MAR ==2:
                    MSTATUS='Single'
          elif MAR == 3:
                    MSTATUS='divorce'
          else:
                    MSTATUS=='widow'
          con = c.connect(host='localhost', username='root', password='root', database='hospital1')
          cur = con.cursor()
          query = "update dctreg set fullname = %s , address = %s , city = %s ,state = %s , zips = %s , country = %s , phoneno = %s  ,email = %s ,passportno = %s , citizenship = %s , nospouse = %s , emgcontact = %s, specify=%s, gender=%s,MSTATUS=%s where aplcno= %s"
          arg = (fullname, address, city, state, zips, country, phoneno, email, passportno, citizenship, nospouse, emgcontact, specify,gender,MSTATUS, aplcno)  # Added 'applicationno' again for the WHERE clause.
          cur.execute(query, arg)  # instance change in MYSQL
          con.commit() 
          cur.close()
          con.close()
          messagebox.showinfo('UPDATING', 'DATA UPDATED SUCCESSFULLY')
          b3['state'] = tk.NORMAL
          b2['state'] = tk.DISABLED
          b1['state'] = tk.NORMAL
          b4['state'] = tk.DISABLED
          b5['state'] = tk.NORMAL
          b6['state'] = tk.NORMAL
          b7['state'] = tk.NORMAL

    
def back():
           p.destroy()
           os.system('dashboard.py')

def delete():
           MAR=Mstatus.get()
           MART= ''
           if MAR==1:
                    MART='Married'
           elif MAR ==2:
                    MART='Single'
           elif MAR == 3:
                    MART='divorce'
           else:
                    MART=='widow'
           fullname = var1.get()
           aplcno = var2.get()
           address = var3.get()
           city = var4.get()
           state = var5.get()
           zips = var6.get()
           country = var7.get()
           phoneno = var8.get()
           email = var9.get()
           passportno = var10.get()
           citizenship = var11.get()
           nospouse = var12.get()
           emgcontact =var13.get()
           specify=var17.get()
           gender=var18.get()
           # Validate 'zips' before using it in the query
           if not zips:
                    
                   messagebox.showerror('Error', 'Zip code cannot be empty')
                   return
           con=c.connect(host='localhost',username='root',password='root',database='hospital1')
           #join mysql-database and python dynamically  ,host-(server)
           cur=con.cursor()#temporary memory that fire(execute) the SQL quries
           query = 'DELETE FROM dctreg WHERE fullname = %s AND aplcno = %s AND address = %s AND city = %s AND state = %s AND zips = %s AND country= %s AND email = %s AND  passportno = %s AND  citizenship = %s AND nospouse = %s AND emgcontact = %s AND specify = %s AND gender = %s'
           arg=( fullname ,aplcno , address , city , state, zips , country, email , passportno ,citizenship ,nospouse,emgcontact,specify,gender)#tuple
           cur.execute(query,arg) #run the query
           con.commit()  #instant change in MYSQL
           cur.close()
           con.close()
           messagebox.showinfo("FIRE",'DELETION SUCCESSFULLY')
           new()

           
def end():
          p.destroy()
         

p=Tk()
p.config(bg='white')
p.title('software parel')


x_res=p.winfo_screenwidth()
y_res=p.winfo_screenheight()
p.geometry("%dx%d"%(x_res,y_res))

img1= ImageTk.PhotoImage(file="Image\\Logo1.png")
l1=Label(p,image=img1)
l1.place(x=10,y=8.5)
l2=Label(p,text="PDS")
l2.config(bg="white",fg='navy',font=('pmingliu',50,'bold'))
l2.place(x=82,y=14)
# above right side context
l3=Label(p,text="phone no:- 9933441259")
l3.config(bg="white",fg='black',font=('pmingliu',10,'bold'))
l3.place(x=900,y=20)

l4=Label(p,text="fax:- (803) 507-234")
l4.config(bg="white",fg='black',font=('pmingliu',10,'bold'))
l4.place(x=900,y=40)

l5=Label(p,text="Email id :- aiims@24febgmail.com")
l5.config(bg="white",fg='black',font=('pmingliu',10,'bold'))
l5.place(x=900,y=56)

l1=Label(p,text=" __________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________")
l1.config(bg='white',fg='black')
l1.place(x=20,y=80,)

l6=Label(p,text="DOCTOR REGISTRATION FORM")
l6.config(bg="white",fg='black',font=('Arial',30,'bold'))
l6.place(x=25,y=100)


l1=Label(p,text="Full Name: ___________________________________ ")
l1.config(bg='white',fg='black',font=('Arial',15,'bold'))
l1.place(x=60,y=240)

var1=StringVar( )
t1=Entry(p,textvariable=var1);
t1.config(bg='white',width=29,border=0,font=('Arial',17,'bold'))
t1.place(x=170,y=240,height=23)
t1.config(state='disabled')

l5=Label(p,text="Application No:____________")
l5.config(bg='white',fg='black',font=('Arial',15,'bold'))
l5.place(x=600,y=240)
var2=StringVar()
t3=Entry(p,textvariable=var2);
t3.config(bg='white',width=12,border=0,font=('Arial',17,'bold'))
t3.place(x=750,y=240,height=23)
t3.config(state='disabled')

l6=Label(p,text="Address:__________________________________________________________________________________________________")
l6.config(bg='white',fg='black',font=('Arial',15,'bold'))
l6.place(x=60,y=280)
var3=StringVar()
t6=Entry(p,textvariable=var3);
t6.config(bg='white',width=65,border=0,font=('Arial',17,'bold'))
t6.place(x=170,y=280,height=23)
t6.config(state='disabled')

l7=Label(p,text="City:______________________")
l7.config(bg='white',fg='black',font=('Arial',15,'bold'))
l7.place(x=60,y=330,)
var4=StringVar()
t7=Entry(p,textvariable=var4);
t7.config(bg='white',width=15,border=0,font=('Arial',17,'bold'))
t7.place(x=112,y=330,height=23)
t7.config(state='disabled')

l8=Label(p,text="State:__________________")
l8.config(bg='white',fg='black',font=('Arial',15,'bold'))
l8.place(x=370,y=330)
var5=StringVar()
t8=Entry(p,textvariable=var5);
t8.config(bg='white',width=15,border=0,font=('Arial',17,'bold'))
t8.place(x=440,y=330,height=23)
t8.config(state='disabled')

l9=Label(p,text="Zip/Postal code:________________________")
l9.config(bg='white',fg='black',font=('Arial',15,'bold'))
l9.place(x=650,y=330)
var6=StringVar()
t9=Entry(p,textvariable=var6);
t9.config(bg='white',width=20,border=0,font=('Arial',17,'bold'))
t9.place(x=820,y=330,height=23)
t9.config(state='disabled')

l10=Label(p,text="Country:__________________")
l10.config(bg='white',fg='black',font=('Arial',15,'bold'))
l10.place(x=960,y=330)
var7=StringVar()
t10=Entry(p,textvariable=var7);
t10.config(bg='white',width=15,border=0,font=('Arial',17,'bold'))
t10.place(x=1050,y=330,height=23)

l11=Label(p,text="Phone no:________________________________")
l11.config(bg='white',fg='black',font=('Arial',15,'bold'))
l11.place(x=60,y=380)
var8=StringVar()
t11=Entry(p,textvariable=var8);
t11.config(bg='white',width=29,border=0,font=('Arial',17,'bold'))
t11.place(x=170,y=380,height=23)
t11.config(state='disabled')

l13=Label(p,text="Email Address:_____________________________________________________")
l13.config(bg='white',fg='black',font=('Arial',15,'bold'))
l13.place(x=520,y=380)
var9=StringVar()
t13=Entry(p,textvariable=var9);
t13.config(bg='white',width=29,border=0,font=('Arial',17,'bold'))
t13.place(x=680,y=380,height=23)
t13.config(state='disabled')

l14=Label(p,text="Passport no:___________________________________")
l14.config(bg='white',fg='black',font=('Arial',15,'bold'))
l14.place(x=60,y=480)
var10=StringVar()
t14=Entry(p,textvariable=var10);
t14.config(bg='white',width=29,border=0,font=('Arial',17,'bold'))
t14.place(x=190,y=480,height=23)
t14.config(state='disabled')

l15=Label(p,text="Citizenship:_________________________________________________")
l15.config(bg='white',fg='black',font=('Arial',15,'bold'))
l15.place(x=600,y=480)
var11=StringVar()
t15=Entry(p,textvariable=var11);
t15.config(bg='white',width=26,border=0,font=('Arial',17,'bold'))
t15.place(x=720,y=480,height=23)
t15.config(state='disabled')

l16=Label(p,text="Name of spouse (if applicable) :___________________________________")
l16.config(bg='white',fg='black',font=('Arial',15,'bold'))
l16.place(x=60,y=530)
var12=StringVar()
t16=Entry(p,textvariable=var12);
t16.config(bg='white',width=29,border=0,font=('Arial',17,'bold'))
t16.place(x=370,y=530,height=23)
t16.config(state='disabled')

l17=Label(p,text="Emergency Contact no :__________________________")
l17.config(bg='white',fg='black',font=('Arial',15,'bold'))
l17.place(x=750,y=530)
var13=StringVar()
t17=Entry(p,textvariable=var13);
t17.config(bg='white',width=25,border=0,font=('Arial',17,'bold'))
t17.place(x=1050,y=530,height=23)
t17.config(state='disabled')

#drop down
var18=StringVar(p)
var18.set("GENDER")#default value set in drop down list
drop=OptionMenu(p,var18,'MALE' ,'FEMALE','TRANSGENDER')   #drop down list
drop.place(x=1100,y=100,)
drop.config(bg='WHITE',fg='black',font=('Arial',15,'bold'))



#CALENDAR

var16= StringVar()
l9=Label(p,textvariable=var16,width=20,font=('Arial',15,'bold'))
l9.config(bg='white',fg='black')
l9.place(x=150,y=170)
cal = Calendar(p, selectmode="day", year=2024, month=1, day=8)
bc1 = Button(p, text="Choose DOB", width=0, height=0, command=down)
bc1.config(bg="white",fg='black',font=('Arial',10,'bold'))
bc1.place(x=60, y=170)


#Menu button

var17=StringVar(p)
var17.set("Department")
drop=OptionMenu(p,var17,'Cardiologist','Dermatologist','Endocrinologist','Gastroenterologist','Neurologist','Orthopedic Surgeon','Pediatrician','Allergist/Immunologist','Psychiatrist','Anesthesiologist','Pediatrician','Radiologist','Urologist','Any other')
drop.place(x=1100,y=140)
drop.config(bg='white',fg='black',font=('Arial',15,'bold'))

#Radiobutton
l12=Label(p,text="Martial Status : ")
l12.config(bg='white',fg='black',font=('Arial',19,'bold'))
l12.place(x=60,y=430)
Mstatus=IntVar()

r1=Radiobutton(p, text="Married", variable=Mstatus,value=1)
r1.config(bg='white',width=15,height=1,font=('Arial',15,'bold'))
r1.place(x=250,y=430)


r2=Radiobutton(p, text="single", variable=Mstatus,value=2)
r2.config(bg='white',width=15,height=1,font=('Arial',15,'bold'))
r2.place(x=450,y=430)

r3=Radiobutton(p, text="divorce", variable=Mstatus,value=3)
r3.config(bg='white',width=15,height=1,font=('Arial',15,'bold'))
r3.place(x=650,y=430)

r4=Radiobutton(p, text="widow", variable=Mstatus,value=4)
r4.config(bg='white',width=15,height=1,font=('Arial',15,'bold'))
r4.place(x=850,y=430)


b1=Button(p,text="NEW",command=new)
b1.config(bg='red',fg='white',font=('Arial',12,'bold'))
b1.place(x=800,y=640)

b2=Button(p,text="SAVE",command=save)
b2.config(bg='red',fg='white',font=('Arial',12,'bold'))
b2.place(x=860,y=640)
b2['state']=tk.DISABLED

b3=Button(p,text="SEARCH",command=search)
b3.config(bg='red',fg='white',font=('Arial',12,'bold'))
b3.place(x=930,y=640)

b4=Button(p,text="UPDATE",command=update)
b4.config(bg='red',fg='white',font=('Arial',12,'bold'))
b4.place(x=1020,y=640)
b4['state']=tk.DISABLED

b5=Button(p,text="BACK",command=back)
b5.config(bg='red',fg='white',font=('Arial',12,'bold'))
b5.place(x=1110,y=640)


b6=Button(p,text="Delete",command=delete)
b6.config(bg='red',fg='white',font=('Arial',12,'bold'))
b6.place(x=1190,y=640)
b6['state']=tk.DISABLED

b7=Button(p,text="EXIT",command=end)
b7.config(bg='red',fg='white',font=('Arial',12,'bold'))
b7.place(x=1280,y=640)

def MST ():
          status2=Mstatus.get()
          Mstatus1=''
          if status2==1:
                    Mstatus1="Married"
          elif status2==2:
                    Mstatus1="single"
          elif status2==3:
                    Mstatus1="divorce"
          elif status2==4:
                    Mstatus1="widow"

p.mainloop()



