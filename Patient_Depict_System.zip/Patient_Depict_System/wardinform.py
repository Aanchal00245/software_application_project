from tkinter import *
from PIL import ImageTk,Image
import os

def end():
            p.destroy()
          
p=Tk()
p.config(bg='#ef082a')
p.title('software parel')


x_res=p.winfo_screenwidth()
y_res=p.winfo_screenheight()
p.geometry("%dx%d"%(x_res,y_res))

l1=Label(p,text="WARD INFORMATION")
l1.config(bg="#213e50",fg='white',font=('Arial',20,'bold'),width=60)
l1.place(x=150,y=60)



img1= ImageTk.PhotoImage(file="Image\\Logo1.png")
l1=Label(p,image=img1)
l1.place(x=10,y=8)

l3=Label(p,text="Patient Full Name: _________________________________ ")
l3.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l3.place(x=60,y=120)
var1=StringVar( )
t1=Entry(p,textvariable=var1);
t1.config(bg='#a1e0e9',width=40,border=0,font=('Arial',17,'bold'))
t1.place(x=252,y=119,height=23)



l4=Label(p,text="Maiden:_______________________________________________________")
l4.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l4.place(x=650,y=120)
var2=StringVar()
t2=Entry(p,textvariable=var2);
t2.config(bg='#a1e0e9',width=40,border=0,font=('Arial',17,'bold'))
t2.place(x=750,y=119,height=23)

l5=Label(p,text="Address:___________________________________")
l5.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l5.place(x=60,y=170)
var3=StringVar()
t3=Entry(p,textvariable=var3);
t3.config(bg='#a1e0e9',width=40,border=0,font=('Arial',17,'bold'))
t3.place(x=150,y=170,height=23)

l6=Label(p,text="State:________________")
l6.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l6.place(x=560,y=170)
var6=StringVar()
t6=Entry(p,textvariable=var6);
t6.config(bg='#a1e0e9',width=40,border=0,font=('Arial',17,'bold'))
t6.place(x=630,y=170,height=23)

l7=Label(p,text="City:___________________")
l7.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l7.place(x=800,y=170,)
var7=StringVar()
t7=Entry(p,textvariable=var7);
t7.config(bg='#a1e0e9',width=15,border=0,font=('Arial',17,'bold'))
t7.place(x=850,y=170,height=23)

l8=Label(p,text="Zip:______________________")
l8.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l8.place(x=1055,y=170)
var8=StringVar()
t8=Entry(p,textvariable=var8);
t8.config(bg='#a1e0e9',width=15,border=0,font=('Arial',17,'bold'))
t8.place(x=1100,y=170,height=23)

l9=Label(p,text="DOB:________________________")
l9.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l9.place(x=60,y=210)
var9=StringVar()
t9=Entry(p,textvariable=var9);
t9.config(bg='#a1e0e9',width=20,border=0,font=('Arial',17,'bold'))
t9.place(x=120,y=210,height=23)

l10=Label(p,text="SSN:________________")
l10.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l10.place(x=430,y=210)
var10=StringVar()
t10=Entry(p,textvariable=var10);
t10.config(bg='#a1e0e9',width=15,border=0,font=('Arial',17,'bold'))
t10.place(x=490,y=210,height=23)

l11=Label(p,text="Phone no:___________________________________________________")
l11.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l11.place(x=670,y=210)
var11=StringVar()
t11=Entry(p,textvariable=var11);
t11.config(bg='#a1e0e9',width=29,border=0,font=('Arial',17,'bold'))
t11.place(x=770,y=210,height=23)

l12=Label(p,text="Martial Status :  🔲Married       🔲divorce     🔲Single    🔲Widow")
l12.config(bg='#a1e0e9',fg='black',font=('Arial',19,'bold'))
l12.place(x=60,y=250)

l13=Label(p,text="Email Address:___________________________________")
l13.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l13.place(x=60,y=300)
var13=StringVar()
t13=Entry(p,textvariable=var13);
t13.config(bg='#a1e0e9',width=29,border=0,font=('Arial',17,'bold'))
t13.place(x=210,y=300,height=23)

l14=Label(p,text="Occupation:___________________________________")
l14.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l14.place(x=400,y=300)
var14=StringVar()
t14=Entry(p,textvariable=var14);
t14.config(bg='#a1e0e9',width=29,border=0,font=('Arial',17,'bold'))
t14.place(x=520,y=300,height=23)

l15=Label(p,text="Employer:______________________________")
l15.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l15.place(x=905,y=300)
var15=StringVar()
t15=Entry(p,textvariable=var15);
t15.config(bg='#a1e0e9',width=26,border=0,font=('Arial',17,'bold'))
t15.place(x=1009,y=300,height=23)

l16=Label(p,text="Spouse Name:___________________________________")
l16.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l16.place(x=60,y=350)
var16=StringVar()
t16=Entry(p,textvariable=var16);
t16.config(bg='#a1e0e9',width=29,border=0,font=('Arial',17,'bold'))
t16.place(x=210,y=350,height=23)

l17=Label(p,text="Emergency Contact no :_____________________________")
l17.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l17.place(x=450,y=350)
var17=StringVar()
t17=Entry(p,textvariable=var17);
t17.config(bg='#a1e0e9',width=29,border=0,font=('Arial',17,'bold'))
t17.place(x=685,y=350,height=23)

l18=Label(p,text="Relation:____________________________")
l18.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l18.place(x=945,y=350)
var18=StringVar()
t18=Entry(p,textvariable=var18);
t18.config(bg='#a1e0e9',width=26,border=0,font=('Arial',17,'bold'))
t18.place(x=1042,y=350,height=23)

l20=Label(p,text="Insurance Company:_____________________________________")
l20.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l20.place(x=60,y=450)
var20=StringVar()
t20=Entry(p,textvariable=var20);
t20.config(bg='#a1e0e9',width=30,border=0,font=('Arial',17,'bold'))
t20.place(x=260,y=450,height=23)

l21=Label(p,text="ID:______________________________________________________")
l21.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l21.place(x=690,y=450)
var21=StringVar()
t21=Entry(p,textvariable=var21);
t21.config(bg='#a1e0e9',width=30,border=0,font=('Arial',17,'bold'))
t21.place(x=720,y=450,height=23)

l22=Label(p,text="Plan:___________________________________________")
l22.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l22.place(x=60,y=500)
var22=StringVar()
t22=Entry(p,textvariable=var22);
t22.config(bg='#a1e0e9',width=30,border=0,font=('Arial',17,'bold'))
t22.place(x=120,y=500,height=23)

l23=Label(p,text="Group:___________________________________________________________")
l23.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l23.place(x=600,y=500)
var23=StringVar()
t23=Entry(p,textvariable=var22);
t23.config(bg='#a1e0e9',width=30,border=0,font=('Arial',17,'bold'))
t23.place(x=670,y=500,height=23)

l24=Label(p,text="PolicyHolderName:________________________________")
l24.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l24.place(x=60,y=550)
var24=StringVar()
t24=Entry(p,textvariable=var24);
t24.config(bg='#a1e0e9',width=30,border=0,font=('Arial',17,'bold'))
t24.place(x=250,y=550,height=23)

l25=Label(p,text="Policy Holder Contact no:___________________________________________")
l25.config(bg='#a1e0e9',fg='black',font=('Arial',15,'bold'))
l25.place(x=600,y=550)
var25=StringVar()
t25=Entry(p,textvariable=var25);
t25.config(bg='#a1e0e9',width=30,border=0,font=('Arial',17,'bold'))
t25.place(x=850,y=550,height=23)


b2=Button(p,text="SUBMIT",command=end)
b2.config(bg='#00809b',fg='white',font=('Arial',12,'bold'))
b2.place(x=1200,y=640)
p.mainloop()










