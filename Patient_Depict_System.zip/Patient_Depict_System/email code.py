import smtplib # only for textual information
def send_email():
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login("pallmpalle@gmail.com", "heje mufl bath inmp")
    bednumber=var10.get()
    message = "Your registration is successfull in pds and your bed no.alloted is "+ bednumber 
    server.sendmail('Mail for You', 'amitpathak1402@gmail.com', message)
    server.quit()

send_email()
