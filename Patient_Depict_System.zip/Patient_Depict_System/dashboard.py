from tkinter import *
from PIL import ImageTk,Image
import os
import mysql.connector
from tkinter import ttk
from tkinter import messagebox
mydb = mysql.connector.connect(host='localhost',
                                         database='hospital1',
                                         user='root',
                                         password='root'
                                         )

mycursor=mydb.cursor()
def ShowallP():
    class A(Frame):
        def __init__(self, parent):
            Frame.__init__(self, parent)
            self.CreateUI()
            self.LoadTable()
            self.grid(sticky=(N, S, W, E))
            parent.grid_rowconfigure(0, weight=1)
            parent.grid_columnconfigure(0, weight=1)
        def CreateUI(self):
            #messagebox.showinfo('A1','A1')#testing
            tv=ttk.Treeview(self)
            tv['columns']=( 'full name', 'aplcno', 'phoneno', 'specify')
            tv.heading('#0',text='full name',anchor='center')
            tv.column('#0',anchor='center')
            tv.heading('#1', text='aplcno', anchor='center')
            tv.column('#1', anchor='center')
            tv.heading('#2', text='phoneno', anchor='center')
            tv.column('#2', anchor='center')
            tv.heading('#3', text='specify', anchor='center')
            tv.column('#3', anchor='center')
            tv.grid(sticky=(N,S,W,E))
            self.treeview = tv
            self.grid_rowconfigure(0,weight=1)
            self.grid_columnconfigure(0,weight=1)
        def LoadTable(self):
            #messagebox.showinfo('A2','A2')
            Select="Select * from dctreg"
            mycursor.execute(Select)
            result=mycursor.fetchall()
            fullname=""
            aplcno=""
            phoneno=""
            specify=""
            
           
            for i in result:
                fullname=i[0]
                aplcno=i[2]
                phoneno=i[8]
                specify=i[14]
                
                
               
                self.treeview.insert("",'end',text=fullname,values=(aplcno,phoneno,specify))

    window=Tk()
    w, h = window.winfo_screenwidth(), window.winfo_screenheight()
    window.title("Account list")
    A(window)


    
def HOME ():
          win.destroy()
          
def Patreg():
          os.system('Patientreg.py')

def dctreg():
          os.system('doctoreg.py')
          
def patadmit():
          os.system('patientadmit.py')
def discharge():
    os.system('patient_discharge.py')
          
def NEXTPAGE():
          os.system('wardinfo.py')


          

win=Tk()
win.config(bg='white')
win.title('Software parel')
img1= ImageTk.PhotoImage(file="Image\\dashboard.jpg")
l1=Label(win,image=img1)
l1.place(x=0,y=0)

x_res=win.winfo_screenwidth()
y_res=win.winfo_screenheight()
win.geometry("%dx%d"%(x_res,y_res))

l3=Label(win,text="        DASHBOARD                                                                  ")
l3.config(bg="#213e50",fg='white',font=('Arial',35,'bold'))
l3.place(x=0,y=10)

img2= ImageTk.PhotoImage(file="Image\\Logo1.png")
l2=Label(win,image=img2)
l2.place(x=10,y=8)

b4=Button(win,text="PATIENT REGISTRATION⏩",command= Patreg)
b4.config(bg="#050c16",fg='GOLD', font=('Arial',16,'bold'))
b4.place(x=30,y=245)
img4= ImageTk.PhotoImage(file="Image\\Patientreg.jpg")
l4=Label(win,image=img4)
l4.place(x=100,y=100)

b5=Button(win,text="DOCTOR REGISTRATION⏩",command= dctreg)
b5.config(bg="#050c16",fg='GOLD', font=('Arial',16,'bold'))
b5.place(x=400,y=245)
img5= ImageTk.PhotoImage(file="Image\\doctoreg.jpg")
l5=Label(win,image=img5)
l5.place(x=490,y=90)


b6=Button(win,text="PATIENT ADMIT⏩",command= patadmit)
b6.config(bg="#050c16",fg='GOLD', font=('Arial',16,'bold'))
b6.place(x=760,y=245)
img6= ImageTk.PhotoImage(file="Image\\Birth.jpg")
l6=Label(win,image=img6)
l6.place(x=790,y=89)

b7=Button(win,text="PATIENT DISCHARGE⏩",command=discharge)
b7.config(bg="#050c16",fg='GOLD', font=('Arial',16,'bold'))
b7.place(x=1050,y=245)
img7= ImageTk.PhotoImage(file="Image\\Firstyou2.jpg")
l7=Label(win,image=img7)
l7.place(x=1100,y=89)

b8=Button(win,text="TOTAL PATIENT⏩",)
b8.config(bg="#050c16",fg='GOLD', font=('Arial',16,'bold'))
b8.place(x=55,y=450)
img8= ImageTk.PhotoImage(file="Image\\totalp.jpg")
l8=Label(win,image=img8)
l8.place(x=90,y=300)


b9=Button(win,text="TOTAL DOCTOR⏩",command=ShowallP)
b9.config(bg="#050c16",fg='GOLD', font=('Arial',16,'bold'))
b9.place(x=448,y=450)
img9= ImageTk.PhotoImage(file="Image\\totald.jpg")
l9=Label(win,image=img9)
l9.place(x=479,y=300)

b10=Button(win,text="PATIENT STATUS⏩",)
b10.config(bg="#050c16",fg='GOLD', font=('Arial',16,'bold'))
b10.place(x=760,y=450)
img10= ImageTk.PhotoImage(file="Image\\patients.jpg")
l10=Label(win,image=img10)
l10.place(x=800,y=300)

b11=Button(win,text="EXIT",command= HOME)
b11.config(bg="#050c16",fg='gold', font=('Arial',20,'bold'))
b11.place(x=1200,y=630)#213e50


win.mainloop()
