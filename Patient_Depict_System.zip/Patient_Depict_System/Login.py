from tkinter import *
from PIL import ImageTk, Image
from tkinter import messagebox
import os


def verify():
          username=t1.get()
          password=t2.get()
          if username=='Software' and password=='12345':
                    messagebox.showinfo("User Authentication","Successfully Entered")
                    os.system('dashboard.py')
          else:
                    messagebox.showinfo("User Authentication "," you have enter wrong userID and Password")
                    var1.set('')
                    var2.set('')
                    t1.focus_set( )
                    
def end():
          win.destroy()
          

      
win=Tk()

img= ImageTk.PhotoImage(file="Image\\Loginimg.jpg")
l2=Label(win,image=img)
l2.place(x=0,y=0)


win.title("software Pearl")

win_w=800
win_h=400
x_res=win.winfo_screenwidth()
y_res=win.winfo_screenheight()
x_ax=(x_res/2) - (win_w/2)
y_ax=(y_res/2) - (win_h/2)
win.geometry("%dx%d+%d+%d"%(win_w,win_h,x_ax,y_ax))

l1=Label(win,text='WELCOME                        ')
l1.config(bg="#4b859d",fg="White",font=('Arial',20,'bold'))
l1.place(x=230,y=100)

img3= ImageTk.PhotoImage(file="Image\\Lock.jpg")
l8=Label(win,image=img3)
l8.place(x=540,y=100)


l2=Label(win,text=  '      ')
l2.config(bg='#d3dee0',font=('Arial',150,'bold'))
l2.place(x=230,y=130)

l3=Label(win,text="Enter Username:")
l3.config(bg='#95c4ca',fg='black',font=('Arial',10,'bold'))
l3.place(x=260,y=150)

var1=StringVar()
t1=Entry(win,textvariable=var1);
t1.config(bg='#95c4ca')
t1.place(x=400,y=150)

l4=Label(win,text="Enter password:")
l4.config(bg='#95c4ca',fg='black',font=('Arial',10,'bold'))
l4.place(x=260,y=200)

var2=StringVar()
t2=Entry(win,textvariable=var2,show='*');
t2.config(bg='#95c4ca')
t2.place(x=400,y=200)

b1=Button(win,text="OK",command=verify)
b1.config(bg='#00809b',fg='white',font=('Arial',20,'bold'))
b1.place(x=280,y=250)

b2=Button(win,text="CANCEL",command=end)
b2.config(bg='#00809b',fg='white',font=('Arial',20,'bold'))
b2.place(x=380,y=250)
win.mainloop()




