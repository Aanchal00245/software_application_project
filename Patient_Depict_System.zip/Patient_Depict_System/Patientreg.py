from tkinter import *                                #import tkinter library from python
from tkinter import messagebox             #To show message
from PIL import ImageTk,Image              #For taking image
import tkinter as tk                                   #it is an alias
import os                                                    #to destory and to go to another file
import mysql.connector as c                     # to connect python with MYSQL
from tkcalendar import Calendar
import random                                            #to make calendar




#CALENDAR

down_flag = True
def toggle_calendar():
          global down_flag
          if down_flag:
                    var7.set(str(cal.get_date()))
                    cal.place(x=300, y=170, height=245, width=245)
                    down_flag = False
          else:
                     var7.set(str(cal.get_date()))
                     cal.place(x=0, y=0, height=0, width=0)
                     down_flag = True

                    
def new():
          
          var1.set('')#to make the entry box empty
          var2.set('')
          var3.set('')
          var4.set('')
          var5.set('')
          var6.set('')
          var7.set('')
          var8.set('')
          var9.set('')
          var10.set('')
          var11.set('')
          var12.set('')
          var13.set('')
          var14.set('')
          var15.set('')
          var16.set('')
          var17.set('')
          var18.set('')
          var19.set('')
          var20.set('')
          var21.set('')
          var22.set('')
          t1.config(state='normal')
          t2.config(state='normal')
          t3.config(state='normal')
          t4.config(state='normal')
          t5.config(state='normal')
          t6.config(state='normal')
          t8.config(state='normal')
          t9.config(state='normal')
          t10.config(state='normal')
          t11.config(state='normal')
          t12.config(state='normal')
          t13.config(state='normal')
          t14.config(state='normal')
          t15.config(state='normal')
          t16.config(state='normal')
          t17.config(state='normal')
          t18.config(state='normal')
          t19.config(state='normal')
          t20.config(state='normal')
          t21.config(state='normal')
          
          

          
          b1['state']=tk.DISABLED
          b2['state']=tk.NORMAL
          b3['state']=tk.NORMAL
          b4['state']=tk.DISABLED
          b5['state']=tk.NORMAL
          b6['state']=tk.DISABLED
          b7['state']=tk.NORMAL
          Mstatus.set(None)
         
          t1.focus_set()#to set the cursor on given entry box
          
def save():
             
          if not all([var1.get(), var16.get(), var2.get(), var3.get(), var4.get(), var5.get(), var6.get(), var7.get(), var8.get(), var9.get(), var10.get(), var11.get(), var12.get(), var13.get(), var17.get(), var18.get()]):
              messagebox.showerror("Error", "Please fill all the fields")
              return 
          b2['state']=tk.DISABLED#makes the button visible #b1-new
                                                 #b2-save,b3-search,b4-update
          b1['state']=tk.NORMAL#Hide the button
          b3['state']=tk.DISABLED
          b4['state']=tk.NORMAL
          b5['state']=tk.DISABLED
          b6['state']=tk.DISABLED
          b7['state']=tk.DISABLED
          
         
          MAR=Mstatus.get()
          MART= ''
          if MAR==1:
                    MART='Married'
          elif MAR ==2:
                    MART='Single'
          elif MAR == 3:
                    MART='divorce'
          else:
                    MART=='widow'
          
                              
          pname =var1.get()
          preg=var2.get()
          '''
          if not preg.isdigit():
                    messagebox.showerror('Error', 'Invalid value for Patient reg no')
                    return
                    preg = int(preg)
          '''
          address=var3.get()
          state=var4.get()
          city=var5.get()
          zip=var6.get()
          dob=var7.get()
          phno=var8.get()
          email=var9.get()
          occuption=var10.get()
          ename=var11.get()
          sname=var12.get()
          emergency=var13.get()
          relation=var14.get()
          insurance=var15.get()
          ids=var16.get()
          plan=var17.get()
          group=var18.get()
          policyhname=var19.get()
          holderctno=var20.get()
          Age=var21.get()
          gender=var22.get()
          Mst()
          
          con=c.connect(host='localhost',username='root',password='root',database='Hospital1')
          cur=con.cursor()
          query="insert into patreg values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
          arg=(pname,preg,address,state,city,zip,dob,phno,email,occuption, ename,sname,emergency,relation,insurance,ids, plan,group, policyhname, holderctno,Age,gender,MART)                 
          cur.execute(query,arg)
          patreg=random.randint(12000,99000)+random.randint(999,99999)
          messagebox.showinfo('',str(patreg))  
          con.commit() 
          cur.close()
          con.close()
          messagebox.showinfo('VERIFYING ','DATA INSERTED SUCCESSFULLY')
          
         
          
def search():
          preg=var2.get()
          var20.set('')
          con=c.connect(host='localhost',username='root',password='root',database='hospital1')
          cur=con.cursor()     
          query="select * from patreg where preg=%s"
          arg=(preg,)     #tuple
          cur.execute(query,arg)
          res = cur.fetchall()
          messagebox.showinfo('VERIFYING','SEARCHING COMPLETED ')#+str(res)
          var1.set(res[0][0])
          var2.set(res[0][1])
          var3.set(res[0][2])
          var4.set(res[0][3])
          var5.set(res[0][4])
          var6.set(res[0][5])
          var7.set(res[0][6])
          var8.set(res[0][7])
          var9.set(res[0][8])
          var10.set(res[0][9])
          var11.set(res[0][10])
          var12.set(res[0][11])
          var13.set(res[0][12])
          var14.set(res[0][13])
          var15.set(res[0][14])
          var16.set(res[0][15])
          var17.set(res[0][16])
          var18.set(res[0][17])
          var19.set(res[0][18])
          var20.set(res[0][19])
          var21.set(res[0][20])
          var22.set(res[0][21])
          MAR=res[0][22]
          #messagebox.showinfo('',MAR)
          if MAR=='Married':
                    Mstatus.set(value=1)
          elif MAR =='Single':
                    Mstatus.set(value=2)
          elif MAR == 'divorce':
                    Mstatus.set(value=3)
          elif MAR == 'widow':
                    Mstatus.set(value=4)
          
          
          
          
        #  messagebox.showinfo('ok',Mstatus)
          cur.close()
          con.close()
         
          b3['state']=tk.DISABLED
          b2['state']=tk.DISABLED
          b1['state']=tk.NORMAL
          b4['state']=tk.NORMAL
          b5['state']=tk.NORMAL
          b6['state']=tk.NORMAL
          b7['state']=tk.NORMAL         
              
def update():
          MAR=Mstatus.get()
          MART= ''
          if MAR==1:
                    MART='Married'
          elif MAR ==2:
                    MART='Single'
          elif MAR == 3:
                    MART='divorce'
          else:
                    MART=='widow'
          
          
                              
          pname =var1.get()
          preg=var2.get()
          address=var3.get()
          state=var4.get()
          city=var5.get()
          zip=var6.get()
          dob=var7.get()
          phno=var8.get()
          email=var9.get()
          occuption=var10.get()
          employer=var11.get()
          sname=var12.get()
          emergency=var13.get()
          relation=var14.get()
          insurance=var15.get()
          ids=var16.get()
          plan=var17.get()
          group=var18.get()
          policyhname=var19.get()
          holderctno=var20.get()
          Age=var21.get()
          gender=var22.get()
          #Mst()
          con=c.connect(host='localhost',username='root',password='root',database='hospital1')
          cur=con.cursor()
          query ="update patreg set pname = %s, address = %s,state = %s ,city = %s , zips = %s , dob = %s , phno = %s  ,email = %s ,occuption = %s,employer= %s , sname = %s , emergency = %s , relation = %s ,insurance = %s , ids = %s , plan = %s , policyhname = %s , holderctno = %s,Age =%s ,gender =%s, `groups` = %s,MART=%s  where  preg = %s"
          arg=(pname,address,state,city,zip,dob,phno, email,occuption,employer,sname,emergency,relation,insurance,ids, plan,policyhname ,holderctno,Age,gender,group,MART,preg)
          cur.execute(query, arg)#instance change in MYSQL
          con.commit() 
          cur.close()
          con.close()
          messagebox.showinfo('UPDATING','DATA UPDATED SUCCESSFULLY'+str(res))
          b3['state']=tk.NORMAL
          b2['state']=tk.DISABLED
          b1['state']=tk.NORMAL
          b4['state']=tk.DISABLED
          b5['state']=tk.NORMAL
          b6['state']=tk.NORMAL
          b7['state']=tk.NORMAL
          
           
def back():
           p.destroy()
           os.system('dashboard.py')

def delete():
          MAR=Mstatus.get()
          MART= ''
          if MAR==1:
                    MART='Married'
          elif MAR ==2:
                    MART='Single'
          elif MAR == 3:
                    MART='divorce'
          else:
                    MART=='widow'
                    
          pname =var1.get()
          preg=var2.get()
          address=var3.get()
          state=var4.get()
          city=var5.get()
          zips=var6.get()
          dob=var7.get()
          phno=var8.get()
          email=var9.get()
          occuption=var10.get()
          employer=var11.get()
          sname=var12.get()
          emergency=var13.get()
          relation=var14.get()
          insurance=var15.get()
          ids=var16.get()
          plan=var17.get()
          group=var18.get()
          policyhname=var19.get()
          holderctno=var20.get()
          Age=var21.get()
          gender=var22.get()
           # Validate 'zips' before using it in the query
          if not zips:
                    
                   messagebox.showerror('Error', 'Zip code cannot be empty')
                   return
          con=c.connect(host='localhost',username='root',password='root',database='hospital1')
           #join mysql-database and python dynamically  ,host-(server)
          cur=con.cursor()#temporary memory that fire(execute) the SQL quries
          query = 'DELETE FROM patreg WHERE pname = %s AND address = %s AND state = %s AND city = %s AND zips = %s AND dob = %s AND phno = %s AND email = %s AND occuption = %s AND employer = %s AND sname = %s AND emergency = %s AND relation = %s AND insurance = %s AND ids = %s AND plan = %s AND policyhname = %s AND holderctno = %s AND Age = %s AND gender = %s AND `groups` = %s AND MART = %s AND preg = %s'
          arg=(pname,address,state,city,zips,dob,phno, email,occuption,employer,sname,emergency,relation,insurance,ids, plan,policyhname ,holderctno,Age,gender,group,MART,preg)#tuple
          cur.execute(query,arg) #run the query
          con.commit()  #instant change in MYSQL
          cur.close()
          con.close()
          messagebox.showinfo("FIRE",'DELETION SUCCESSFULLY')
          new()

        
def end():
          p.destroy()
         
p=Tk()
p.config(bg='#5eb5c9')
p.title('software parel')


x_res=p.winfo_screenwidth()
y_res=p.winfo_screenheight()
p.geometry("%dx%d"%(x_res,y_res))



l1=Label(p,text="PATIENT REGISTRATION")
l1.config(bg="#020014",fg='white',font=('Arial',20,'bold'),width=60)
l1.place(x=150,y=60)



img1= ImageTk.PhotoImage(file="Image\\Logo1.png")
l1=Label(p,image=img1)
l1.place(x=10,y=8)



l3=Label(p,text="Patient Full Name: _________________________________ ")
l3.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l3.place(x=60,y=120)
#VAR1
var1=StringVar( )
t1=Entry(p,textvariable=var1);
t1.config(bg='#5eb5c9',width=40,border=0,font=('Arial',17,'bold'))
t1.place(x=252,y=119,height=23)
t1.config(state='disabled')



l4=Label(p,text="Patient reg no:___________________________________________")
l4.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l4.place(x=650,y=120)


#VAR2
var2=StringVar()
t2=Entry(p,textvariable=var2);
t2.config(bg='#5eb5c9',width=40,border=0,font=('Arial',17,'bold'))
t2.place(x=850,y=119,height=23)
t2.config(state='disabled')



l5=Label(p,text="Address:___________________________________")
l5.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l5.place(x=60,y=230)


#VAR3
var3=StringVar()
t3=Entry(p,textvariable=var3);
t3.config(bg='#5eb5c9',width=40,border=0,font=('Arial',17,'bold'))
t3.place(x=150,y=230,height=23)
t3.config(state='disabled')


l6=Label(p,text="State:________________")
l6.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l6.place(x=560,y=230)

#VAR4
var4=StringVar()
t4=Entry(p,textvariable=var4);
t4.config(bg='#5eb5c9',width=40,border=0,font=('Arial',17,'bold'))
t4.place(x=630,y=230,height=23)
t4.config(state='disabled')


l7=Label(p,text="City:___________________")
l7.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l7.place(x=800,y=230,)
#VAR5
var5=StringVar()
t5=Entry(p,textvariable=var5);
t5.config(bg='#5eb5c9',width=15,border=0,font=('Arial',17,'bold'))
t5.place(x=850,y=230,height=23)
t5.config(state='disabled')


l8=Label(p,text="Zip:________________")
l8.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l8.place(x=1055,y=230)
#VAR6
var6=StringVar()
t6=Entry(p,textvariable=var6);
t6.config(bg='#5eb5c9',width=15,border=0,font=('Arial',17,'bold'))
t6.place(x=1100,y=230,height=23)
t6.config(state='disabled')

l11=Label(p,text="Phone no:_____________________")
l11.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l11.place(x=750,y=170)
var8=StringVar()
t8=Entry(p,textvariable=var8);
t8.config(bg='#5eb5c9',width=17,border=0,font=('Arial',17,'bold'))
t8.place(x=860,y=170,height=23)
t8.config(state='disabled')
#RADIOBUTTON
l12=Label(p,text="Martial Status : ")
l12.config(bg='#5eb5c9',fg='black',font=('Arial',19,'bold'))
l12.place(x=60,y=270)
Mstatus=IntVar()

r1=Radiobutton(p, text="Married", variable=Mstatus,value=1)
r1.config(bg='#5eb5c9',width=15,height=1,font=('Arial',19,'bold'))
r1.place(x=250,y=270)


r2=Radiobutton(p, text="single", variable=Mstatus,value=2)
r2.config(bg='#5eb5c9',width=15,height=1,font=('Arial',19,'bold'))
r2.place(x=450,y=270)

r3=Radiobutton(p, text="divorce", variable=Mstatus,value=3)
r3.config(bg='#5eb5c9',width=15,height=1,font=('Arial',19,'bold'))
r3.place(x=650,y=270)

r4=Radiobutton(p, text="widow", variable=Mstatus,value=4)
r4.config(bg='#5eb5c9',width=15,height=1,font=('Arial',19,'bold'))
r4.place(x=850,y=270)


l13=Label(p,text="Email Address:___________________________________")
l13.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l13.place(x=60,y=320)
var9=StringVar()
t9=Entry(p,textvariable=var9);
t9.config(bg='#5eb5c9',width=29,border=0,font=('Arial',17,'bold'))
t9.place(x=210,y=320,height=23)
t9.config(state='disabled')

l14=Label(p,text="Occupation:___________________________________")
l14.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l14.place(x=400,y=320)
var10=StringVar()
t10=Entry(p,textvariable=var10);
t10.config(bg='#5eb5c9',width=29,border=0,font=('Arial',17,'bold'))
t10.place(x=520,y=320,height=23)
t10.config(state='disabled')
l15=Label(p,text="Employer:___________________________")
l15.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l15.place(x=905,y=320)
var11=StringVar()
t11=Entry(p,textvariable=var11);
t11.config(bg='#5eb5c9',width=26,border=0,font=('Arial',17,'bold'))
t11.place(x=1009,y=320,height=23)
t11.config(state='disabled')

l16=Label(p,text="Spouse Name:___________________________________")
l16.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l16.place(x=60,y=370)
var12=StringVar()
t12=Entry(p,textvariable=var12);
t12.config(bg='#5eb5c9',width=29,border=0,font=('Arial',17,'bold'))
t12.place(x=210,y=370,height=23)
t12.config(state='disabled')

l17=Label(p,text="Emergency Contact no :_____________________________")
l17.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l17.place(x=450,y=370)
var13=StringVar()
t13=Entry(p,textvariable=var13);
t13.config(bg='#5eb5c9',width=29,border=0,font=('Arial',17,'bold'))
t13.place(x=685,y=370,height=23)
t13.config(state='disabled')

l18=Label(p,text="Relation:_________________________")
l18.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l18.place(x=945,y=370)
var14=StringVar()
t14=Entry(p,textvariable=var14);
t14.config(bg='#5eb5c9',width=26,border=0,font=('Arial',17,'bold'))
t14.place(x=1042,y=370,height=23)
t14.config(state='disabled')

l19=Label(p,text="INSURANCE INFORMATION ")
l19.config(bg="#020014",fg='white',font=('Arial',12,'bold'),width=125)
l19.place(x=60,y=430)

l20=Label(p,text="Insurance Company:_____________________________________")
l20.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l20.place(x=60,y=470)
var15=StringVar()
t15=Entry(p,textvariable=var15);
t15.config(bg='#5eb5c9',width=30,border=0,font=('Arial',17,'bold'))
t15.place(x=260,y=470,height=23)
t15.config(state='disabled')

l21=Label(p,text="ID:_____________________________________________________")
l21.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l21.place(x=690,y=470)
var16=StringVar()
t16=Entry(p,textvariable=var16);
t16.config(bg='#5eb5c9',width=30,border=0,font=('Arial',17,'bold'))
t16.place(x=720,y=470,height=23)
t16.config(state='disabled')

l22=Label(p,text="Plan:___________________________________________")
l22.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l22.place(x=60,y=520)
var17=StringVar()
t17=Entry(p,textvariable=var17);
t17.config(bg='#5eb5c9',width=30,border=0,font=('Arial',17,'bold'))
t17.place(x=120,y=520,height=23)
t17.config(state='disabled')

l23=Label(p,text="Group:___________________________________________________________")
l23.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l23.place(x=600,y=520)
var18=StringVar()
t18=Entry(p,textvariable=var18);
t18.config(bg='#5eb5c9',width=30,border=0,font=('Arial',17,'bold'))
t18.place(x=670,y=520,height=23)
t18.config(state='disabled')


l24=Label(p,text="PolicyHolderName:________________________________")
l24.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l24.place(x=60,y=570)
var19=StringVar()
t19=Entry(p,textvariable=var19);
t19.config(bg='#5eb5c9',width=30,border=0,font=('Arial',17,'bold'))
t19.place(x=250,y=570,height=23)
t19.config(state='disabled')


l25=Label(p,text="Policy Holder Contact no:___________________________________________")
l25.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l25.place(x=600,y=570)
var20=StringVar()
t20=Entry(p,textvariable=var20);
t20.config(bg='#5eb5c9',width=30,border=0,font=('Arial',17,'bold'))
t20.place(x=850,y=570,height=23)
t20.config(state='disabled')

l26=Label(p,text="AGE:________")
l26.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))
l26.place(x=560,y=170)
var21=StringVar()
t21=Entry(p,textvariable=var21);
t21.config(bg='#5eb5c9',width=6,border=0,font=('Arial',17,'bold'))
t21.place(x=620,y=170,height=23)
t21.config(state='disabled')

#drop down
var22=StringVar(p)
var22.set("GENDER")#default value set in drop down list
drop=OptionMenu(p,var22,'MALE' ,'FEMALE','TRANSGENDER')   #drop down list
drop.place(x=1110,y=160,)
drop.config(bg='#5eb5c9',fg='black',font=('Arial',15,'bold'))

b1=Button(p,text="NEW",command=new)
b1.config(bg='red',fg='white',font=('Arial',12,'bold'))
b1.place(x=800,y=640)


b2=Button(p,text="SAVE",command=save)
b2.config(bg='red',fg='white',font=('Arial',12,'bold'))
b2.place(x=860,y=640)
b2['state']=tk.DISABLED

b3=Button(p,text="SEARCH",command=search)
b3.config(bg='red',fg='white',font=('Arial',12,'bold'))
b3.place(x=930,y=640)

b4=Button(p,text="UPDATE",command=update)
b4.config(bg='red',fg='white',font=('Arial',12,'bold'))
b4.place(x=1020,y=640)

b5=Button(p,text="BACK",command=back)
b5.config(bg='red',fg='white',font=('Arial',12,'bold'))
b5.place(x=1110,y=640)


b6=Button(p,text="Delete",command=delete)
b6.config(bg='red',fg='white',font=('Arial',12,'bold'))
b6.place(x=1190,y=640)

b7=Button(p,text="EXIT",command=end)
b7.config(bg='red',fg='white',font=('Arial',12,'bold'))
b7.place(x=1280,y=640)

var7= StringVar()
l9=Label(p,textvariable=var7,width=20,font=('Arial',15,'bold'))
l9.config(bg='#5eb5c9',fg='black')
l9.place(x=100,y=170)
cal = Calendar(p, selectmode="day", year=2024, month=1, day=8)
bc1 = Button(p, text="Choose DOB", width=0, height=0, command=toggle_calendar)
bc1.config(bg="#5eb5c9",fg='black',font=('Arial',10,'bold'))
bc1.place(x=60, y=170)

def Mst ():
          status2=Mstatus.get()
          Mstatus1=''
          if status2==1:
                    Mstatus1="Married"
          elif status2==2:
                    Mstatus1="single"
          elif status2==3:
                    Mstatus1="divorce"
          elif status2==4:
                    Mstatus1="widow"






p.mainloop()





