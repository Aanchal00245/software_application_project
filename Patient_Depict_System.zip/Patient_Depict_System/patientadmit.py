from tkinter import *                                #import tkinter library from python
from PIL import ImageTk,Image              #For taking image
import tkinter as tk                                   #it is an alias
import os
from tkcalendar import Calendar
import mysql.connector as c
from tkinter import messagebox
import time
import mysql.connector

def showpat():
     PATIENT_NAME=var1.get()
     htcon=mysql.connector.connect(host='localhost',username='root',password='root',database='hospital1')

     cur=htcon.cursor()
     query='select * from patreg where  pname=%s'
     arg=(PATIENT_NAME,)
     cur.execute(query,arg)
     res=cur.fetchall()
     messagebox.showinfo("EXECUTE",'details found')
     
     regno.set(res[0][1])
     patname.set(res[0][0])
     patage.set(res[0][20])
     var4.set(res[0][21])
     phno.set(res[0][7])
              
     cur.close()
     htcon.close()


def new() :
     
          patname.set('')
          var1.set("PATIENT NAME")#to make the entry box empty
          regno.set('')
          patage.set('')
          var4.set('Gender')
          var5.set('WARD')
          var6.set('Medical Specialists')
          var7.set('DISEASE NAME')
          var8.set('BLOOD GROUP')
          var9.set('BED TYPE')
          var10.set('BED NUMBER')
          var11.set('')
          var12.set('')
          var13.set('')
          var14.set('')
          var15.set('')
          C1.deselect()
          C2.deselect()
          C3.deselect()
          C4.deselect()
          C5.deselect()
          t1.config(state='normal')
          t2.config(state='normal')
          t3.config(state='normal')
          
          
        
         
def save():
     pname=var1.get()
     age=patage.get()
     gender=var4.get()
     registration=regno.get()
     admission=patdate.get()
     phone=phno.get()
     ward=var5.get()
     medspeciality=var6.get()
     disname=var7.get()
     bloodgrp=var8.get()
     bedtype=var9.get()
     bednumber=var10.get()
     FOOD=var11.get()
     VEHICLE_CHAIR=var12.get()
     MEDICIEN=var13.get()
     BLOOD_BANK=var14.get()
     MEDICLAIM=var15.get()
     STATUS=1
     
     foodserve=''
     if FOOD == 1:
          foodserve='aquired'
     else:
          foodserve='not aquired'
          
     vchair=''
     if VEHICLE_CHAIR== 1:
          vchair='aquired'
     else:
          vchair='not aquired'
     med=''
     if MEDICIEN== 1:
          med='aquired'
     else:
          med='not aquired'
          
     bloodbank=''
     if BLOOD_BANK== 1:
          bloodbank='aquired'
     else:
          bloodbank='not aquired'
          
     medclaim=''
     if MEDICLAIM== 1:
          medclaim='aquired'
     else:
          medclaim='not aquired'
          
     
          
     #messagebox.showinfo('VERIFYING ', str(FOOD)+' '+str(VEHICLE_CHAIR)+' '+str(MEDICINE)+' '+str(BLOOD_BANK)+' '+str(MEDICLAIM)+' '+str(STATUS)+' ')     
     con=c.connect(host='localhost',username='root',password='root',database='hospital1')
     cur=con.cursor()
     query ="insert into patadmit (PATIENT_NAME,REGISTRATION_NO,AGE,GENDER,ADMISSIONDATE,WARD,MEDICAL_SPECIALITY,DISEASE,BLOOD_GROUP,BED_TYPE,BEDNUMBER,PHONENO,FOOD,VEHICLE_CHAIR,MEDICIEN,BLOODBANK,MEDICLAIM,STATUS) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
     arg=(pname,registration,age,gender,admission,ward,medspeciality,disname,bloodgrp,bedtype,bednumber,phone,foodserve,vchair,med,bloodbank,medclaim,STATUS)
     cur.execute(query, arg)#instance change in MYSQL
     con.commit() 
     cur.close()
     con.close()
     messagebox.showinfo('UPDATING','DATA UPDATED SUCCESSFULLY')
          


          
def exit():
          pass


def update_admission_time():
    admission_time = time.strftime(" %H:%M:%S")  # Get current timetime.strftime() is used to retrieve the current time in the format %Y-%m-%d %H:%M:%S (Year-Month-Day Hour:Minute:Second).
    patupdatetime.set(admission_time)  # Update admission time label

def update_custom_time():
    custom_time = entry_custom_time.get()  # Get user input time
    patupdatetime.set(custom_time)  # Update admission time label
    
def dyname():
    L=[]
    

    htcon=mysql.connector.connect(host='localhost',username='root',password='root',database='hospital1')
    cur=htcon.cursor()
    query='select*from patreg '
    #arg=(idnumber,)
    cur.execute(query)
    res=cur.fetchall()
    for i in range(0,len(res)):
        L.append(res[i][0])
    return L




#CALENDAR
down=True
def down():
          global down
          if down:
                    patdate.set(str(cal.get_date()))
                    cal.place(x=140, y=100, height=245, width=245)
                    down= False
          else:
                     patdate.set(str(cal.get_date()))
                     cal.place(x=0, y=0, height=0, width=0)
                     down= True


#creating the tkinter window
p=Tk()
p.config(bg='#74a89b')
p.title('software parel')


#Getting Screen Resolution:
x_res=p.winfo_screenwidth()
y_res=p.winfo_screenheight()
#Setting Window Geometry
p.geometry("%dx%d"%(x_res,y_res))
#Creating a Frame Widget:
'''
FLAT: No border.
RAISED: Creates a raised border.
SUNKEN: Creates a sunken border.
GROOVE: Creates a grooved border.
RIDGE: Creates a ridged border.
'''
Dataframe = Frame(p, bd=20, relief=GROOVE,bg='#639186')#bd=border width of 20,RIDGE
Dataframe.place( width=1369, height=100)

label = Label(Dataframe, text='PATIENT ADMIT FORM', font=('Arial', 40,'bold'), fg='#abc2c4',bg='#1f2c2a')
label.pack()#Label is packed inside the Dataframe

Dataframe1 = Frame(p, bd=10, relief=GROOVE,bg='#688b83')
Dataframe1.place( x=0,y=150,width=1000, height=300)

Dataframe2 = Frame(p, bd=10, relief=GROOVE,bg='#688b83')
Dataframe2.place( x=1000,y=120,width=360, height=300)

Dataframe3 = Frame(p, bd=8, relief=GROOVE,bg='#435652')
Dataframe3.place( x=0,y=420,width=1358, height=50)

Dataframe4 = Frame(p, bd=10, relief=GROOVE,bg='#688b83')
Dataframe4.place( x=0,y=470,width=1358, height=230)

Dataframe5 = Frame(p, bd=0, relief=GROOVE,bg='#435652')
Dataframe5.place( x=545,y=480,width=800, height=215)
label = Label(Dataframe5, text='OTHER SERVICE', font=('Arial', 20,'bold'), fg='#abc2c4',bg='#1f2c2a')
label.pack()#Label is packed inside the Dataframe


#drop down
L=dyname()
var1=StringVar(p)
var1.set("PATIENT NAME")#default value set in drop down list
drop=OptionMenu(p,var1,*L)   #drop down list
drop.place(x=10,y=160,)
drop.config(bg='#31453b',fg='#ced9d6',font=('Arial',15,'bold'))

#show button
b5=Button(p,text="show",command=showpat)
b5.config(bg='red',fg='white',font=('Arial',13,'bold'))
b5.place(x=800,y=163)

l1=Label(p,text="REGISTRATION NUMBER")
l1.config(bg='#31453b',fg='#a2afab',font=('Arial',18,'bold'))
l1.place(x=225,y=163)
regno=StringVar()
t1=Entry(p,textvariable=regno);
t1.config(bg='#a3dbcd',width=15,border=0,font=('Arial',18,'bold'))
t1.place(x=540,y=163,height=35)

l3=Label(p,text="PATIENT NAME")
l3.config(bg='#31453b',fg='#a2afab',font=('Arial',18,'bold'))
l3.place(x=10,y=205)
patname=StringVar()
t2=Entry(p,textvariable=patname);
t2.config(bg='#a3dbcd',width=14,border=0,font=('Arial',18,'bold'))
t2.place(x=205,y=205,height=35)

l4=Label(p,text="AGE")
l4.config(bg='#31453b',fg='#a2afab',font=('Arial',18,'bold'))
l4.place(x=400,y=205)
patage=StringVar()
t3=Entry(p,textvariable=patage);
t3.config(bg='#a3dbcd',width=14,border=0,font=('Arial',18,'bold'))
t3.place(x=465,y=205,height=35)

#DROPDOWN
var7=StringVar(p)
var7.set("DISEASE NAME")#default value set in drop down list
drop=OptionMenu(p,var7,'Diabetes' ,'Hypertension','Stroke (cerebrovascular accident)','Chronic obstructive pulmonary disease (COPD)','Asthma','Cancer','HIV/AIDS','Tuberculosis (TB)','Malaria','Dengue',' fever','Pneumonia','Gastritis','Chronic kidney disease','Eczema','Anemia','OTHERS')   #drop down list
drop.place(x=10,y=480,)
drop.config(bg='#31453b',fg='#ced9d6',font=('Arial',15,'bold'))

var8=StringVar(p)
var8.set(" BLOOD GROUP")#default value set in drop down list
drop=OptionMenu(p,var8,'A+','B+','AB+','O+','A-','B-','AB-','O-','OTHERS')   #drop down list
drop.place(x=10,y=525,)
drop.config(bg='#31453b',fg='#ced9d6',font=('Arial',15,'bold'))

var9=StringVar(p)
var9.set(" BED TYPE")#default value set in drop down list
drop=OptionMenu(p,var9,'FULLY ELECTRIC BED' ,'SEMI ELECTRIC BED','NORMAL BED','ICU','OT','OTHERS')   #drop down list
drop.place(x=10,y=570,)
drop.config(bg='#31453b',fg='#ced9d6',font=('Arial',15,'bold'))

var6=StringVar(p)
var6.set("Medical Specialists")#default value set in drop down list
drop=OptionMenu(p,var6,'Cardiologist','Dermatologist','Endocrinologist','Gastroenterologist','Neurologist','Orthopedic Surgeon','Pediatrician','Allergist/Immunologist','Psychiatrist','Anesthesiologist','Pediatrician','Radiologist','Urologist','OTHERS')   #drop down list
drop.place(x=10,y=330,)
drop.config(bg='#31453b',fg='#ced9d6',font=('Arial',15,'bold'))


l10=Label(p,text="PHONE NO")
l10.config(bg='#31453b',fg='#a2afab',font=('Arial',18,'bold'))
l10.place(x=10,y=245)
phno=StringVar()
t10=Entry(p,textvariable=phno);
t10.config(bg='#a3dbcd',width=15,border=0,font=('Arial',18,'bold'))
t10.place(x=150,y=245,height=35)


var5=StringVar(p)
var5.set("WARD")#default value set in drop down list
drop=OptionMenu(p,var5,'Pediatrics Ward' ,'General Ward','Maternity Ward','Psychiatric Ward','ICU WARD','OT WARD','Neonatal Intensive Care Unit (NICU)','PRIVATE ROOM','OTHERS')   #drop down list
drop.place(x=10,y=285,)
drop.config(bg='#31453b',fg='#ced9d6',font=('Arial',15,'bold'))

#CALENDAR

patdate= StringVar()
l5=Label(p,textvariable=patdate,width=20,font=('Arial',15,'bold'))
l5.config(bg='#8e9495',fg='#31453b')
l5.place(x=150,y=110)
cal = Calendar(p, selectmode="day", year=2024, month=1, day=8)
bc1 = Button(p, text="ADMISSION DATE", width=0, height=0, command=down)
bc1.config(bg="#8e9495",fg='#31453b',font=('Arial',10,'bold'))
bc1.place(x=10, y=110)

var10=StringVar(p)
var10.set("BED NUMBER")#default value set in drop down list
drop=OptionMenu(p,var10,'101' ,'102','103','104','105','106','107','108','109','110','111','112')  #drop down list
drop.place(x=10,y=615,)
drop.config(bg='#31453b',fg='#ced9d6',font=('Arial',15,'bold'))


patupdatetime= StringVar()
l6 = Label(p, textvariable=patupdatetime, width=8, font=('Arial', 15, 'bold'))
l6.config(bg='#8e9495', fg='#31453b')
l6.place(x=580, y=110) # Button to update admission time
entry_custom_time = Entry(p, width=10, font=('Arial', 15))
entry_custom_time.config(bg='#8e9495', fg='#31453b')
entry_custom_time.place(x=800, y=110)



# Button to update admission time with custom time
bc3 = Button(p, text="UpdateTime", width=10, height=0, command=update_custom_time)
bc3.config(bg="#8e9495", fg='#31453b', font=('Arial', 10, 'bold'))
bc3.place(x=700, y=110)
bc2 = Button(p, text="Admission Time", width=20, height=0, command=update_admission_time)
bc2.config(bg="#8e9495", fg='#31453b', font=('Arial', 10, 'bold'))
bc2.place(x=400, y=110)
update_admission_time()# Run the update function initially to display the admission time

b1=Button(p,text="NEW",command=new)
b1.config(bg='red',fg='white',font=('Arial',12,'bold'))
b1.place(x=1291,y=135)
b1['state']=tk.NORMAL

b2=Button(p,text="SAVE",command=save)
b2.config(bg='red',fg='white',font=('Arial',12,'bold'))
b2.place(x=1286,y=170)
'''
b3=Button(p,text="DISCHARGE",command=discharge)
b3.config(bg='red',fg='white',font=('Arial',12,'bold'))
b3.place(x=1235,y=206)
'''
b4=Button(p,text="EXIT",command=exit)
b4.config(bg='red',fg='white',font=('Arial',12,'bold'))
b4.place(x=1291,y=205)

var4=StringVar(p)
var4.set("GENDER")#default value set in drop down list
drop=OptionMenu(p,var4,'MALE' ,'FEMALE','TRANSGENDER')   #drop down list
drop.place(x=680,y=205,)
drop.config(bg='#31453b',fg='#ced9d6',font=('Arial',15,'bold'))

var11=IntVar()
C1=Checkbutton(p,text='FOOD',variable=var11)
C1.config(bg="#8e9495", fg='#31453b', font=('Arial', 12, 'bold'))
C1.place(x=560,y=500)

var12=IntVar()
C2=Checkbutton(p,text='VEHICLE CHAIR',variable=var12)
C2.config(bg="#8e9495", fg='#31453b', font=('Arial', 12, 'bold'))
C2.place(x=560,y=536)

var13=IntVar()
C3=Checkbutton(p,text='MEDICINE',variable=var13)
C3.config(bg="#8e9495", fg='#31453b', font=('Arial', 12, 'bold'))
C3.place(x=560,y=572)

var14=IntVar()
C4=Checkbutton(p,text='BLOOD BANK',variable=var14)
C4.config(bg="#8e9495", fg='#31453b', font=('Arial', 12, 'bold'))
C4.place(x=560,y=610)

var15=IntVar()
C5=Checkbutton(p,text='MEDICLAIM',variable=var15)
C5.config(bg="#8e9495", fg='#31453b', font=('Arial', 12, 'bold'))
C5.place(x=560,y=650)


p.mainloop()
